package br.com.ifpr.pgto.Empresa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.ifpr.pgto.Firebase.ConfiguracoesFirebase;
import br.com.ifpr.pgto.Firebase.UsuarioFirebase;
import br.com.ifpr.pgto.Model.Empresa;
import br.com.ifpr.pgto.Model.Funcionario;
import br.com.ifpr.pgto.Principal;
import br.com.ifpr.pgto.R;

public class CadastroFunc extends AppCompatActivity {

    TextView txNome, txCargo, txCPF, txEmail, txDep, txDataAdmissão;
    RadioButton rdSim, rdNao;
    RadioGroup rd;
    EditText edtNome, edtCargo, edtCPF, edtEmail, edtQtDep, edtDataAdmissão;
    Button btnAvança, btnFinaliza;
    RelativeLayout rel;
    Empresa e = UsuarioFirebase.getDadosEmpresaLogada();
    DatabaseReference ref;
    List<Empresa> lista = new ArrayList<Empresa>();
    private FirebaseAuth autenticacao = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_funcionario);

        init();

        btnAvança.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validaCampos();
            }
        });

        rd.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(rdSim.isChecked()){
                    edtQtDep.setVisibility(View.VISIBLE);
                }else if(rdNao.isChecked()){
                    edtQtDep.setVisibility(View.GONE);
                }
            }
        });

        btnFinaliza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validaCamposFinalizar();
                cadastrar();
            }
        });




    }

    public void cadastrar(){
        final Funcionario funcionario = new Funcionario();
        String nome = edtNome.getText().toString();
        String cpf = edtCPF.getText().toString();
        String senha = "semsenha";
        String cargo = edtCargo.getText().toString();
        String email = edtEmail.getText().toString();
        String date;
        int dependentes;

        if(rdNao.isSelected()){
            dependentes = 0;
        }else{
            dependentes= Integer.parseInt(edtQtDep.getText().toString());
        }


        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy"); // Make sure user insert date into edittext in this format.

        Date dateObject;

        try{
            String dob_var=(edtDataAdmissão.getText().toString());

            dateObject = formatter.parse(dob_var);

            date = new SimpleDateFormat("dd/MM/yyyy").format(dateObject);
            funcionario.setDataAdmissao(date);

        }

        catch (java.text.ParseException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
            Log.i("E11111111111", e.toString());
        }

        funcionario.setCpf(cpf);
        funcionario.setEmail(email);
        funcionario.setNome(nome);
        funcionario.setSenha(senha);
        funcionario.setQtDependentes(dependentes);
        funcionario.setCargo(cargo);

        ref = FirebaseDatabase.getInstance().getReference("Empresas").child(e.getId());

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Empresa a = dataSnapshot.getValue(Empresa.class);

                lista.add(a);

                for(Empresa e: lista){
                    funcionario.setEmpresa(e);
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        cadastrarFuncionario(funcionario);

    }

    public void redirecionaLogin(){

        Intent intent = new Intent(this, Principal.class);
        startActivity(intent);

    }

    public void cadastrarFuncionario(final Funcionario emp) {

        autenticacao = ConfiguracoesFirebase.getFirebaseAutenticacao();
        autenticacao.createUserWithEmailAndPassword(
                emp.getEmail(),
                emp.getSenha()
        ).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {


            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if (task.isSuccessful()) {

                    try {
                        String idUsuario = task.getResult().getUser().getUid();
                        emp.setId(idUsuario);
                        emp.salvar();
                        Log.i("tag", "SUCESSO");
                        UsuarioFirebase.AtualizaNome(emp.getNome());
                        redirecionaLogin();
                        Toast.makeText(CadastroFunc.this, "Usuario: "+emp.getNome()+" cadastrado", Toast.LENGTH_SHORT).show();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                } else {

                    String excecao = "";

                    try {
                        throw task.getException();
                    } catch (FirebaseAuthWeakPasswordException e) {

                        excecao = "Digite uma senha mais forte!";
                    } catch (FirebaseAuthUserCollisionException e) {

                        excecao = "Esta conta já está cadastrada";
                        e.printStackTrace();
                    } catch (Exception e) {

                        excecao = "Erro ao cadastrar usuario: " + e.getMessage();
                        e.printStackTrace();
                    }

                    Toast.makeText(CadastroFunc.this,
                            excecao, Toast.LENGTH_SHORT).show();

                }
            }
        });

    }

    public void trocaCampos(){

        edtNome.setVisibility(View.GONE);
        edtEmail.setVisibility(View.GONE);
        edtCPF.setVisibility(View.GONE);
        btnAvança.setVisibility(View.GONE);
        txNome.setVisibility(View.GONE);
        txEmail.setVisibility(View.GONE);
        txCPF.setVisibility(View.GONE);

        edtCargo.setVisibility(View.VISIBLE);
        edtDataAdmissão.setVisibility(View.VISIBLE);

        rd.setVisibility(View.VISIBLE);
        txCargo.setVisibility(View.VISIBLE);
        txDataAdmissão.setVisibility(View.VISIBLE);
        txDep.setVisibility(View.VISIBLE);
        btnFinaliza.setVisibility(View.VISIBLE);



        RelativeLayout.LayoutParams params= new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.BELOW, R.id.toolbar);
        params.addRule(RelativeLayout.CENTER_HORIZONTAL);
        rel.setLayoutParams(params);

    }

    public void validaCampos(){
            boolean validador = true;

            String nome = edtNome.getText().toString();
            String email = edtEmail.getText().toString();
            String cpf = edtCPF.getText().toString();

            if(nome.isEmpty()){
                edtNome.setError("Campo Nome é obrigatótio!");
                validador = false;
            }

            if(email.isEmpty()){
                edtEmail.setError("Campo Email é obrigatótio!");
                validador = false;
            }

            if(cpf.isEmpty()){
                edtCPF.setError("Campo CPF é obrigatótio!");
                validador = false;
            }

            if(validador){

                trocaCampos();
                rdNao.setSelected(true);

            }

    }

    public void validaCamposFinalizar(){
        boolean validador = true;

        String cargo = edtNome.getText().toString();
        String data = edtDataAdmissão.getText().toString();


        if(cargo.isEmpty()){
            edtNome.setError("Campo Cargo é obrigatótio!");
            validador = false;
        }

        if(data.isEmpty()){
            edtEmail.setError("Campo Email é obrigatótio!");
            validador = false;
        }


        if(validador){

            trocaCampos();

        }

    }

    public void init(){
        txNome = findViewById(R.id.txNomeFunc);
        txCargo = findViewById(R.id.txCargoFunc);
        txCPF = findViewById(R.id.txCPFFunc);
        txEmail = findViewById(R.id.txEmailFunc);
        txDep = findViewById(R.id.txDependentes);
        txDataAdmissão = findViewById(R.id.txDataAdmissaoFunc);

        rel = findViewById(R.id.relaCargo);

        btnAvança = findViewById(R.id.btnAvançar1);
        btnFinaliza = findViewById(R.id.btnAvançar2);

        rdSim = findViewById(R.id.sim);
        rdNao = findViewById(R.id.nao);
        rd = findViewById(R.id.radioGroup);

        edtNome = findViewById(R.id.edtNomeFunc);
        edtCargo = findViewById(R.id.edtCargoFunc);
        edtCPF = findViewById(R.id.edtCpfFunc);
        edtEmail = findViewById(R.id.edtEmailFunc);
        edtQtDep = findViewById(R.id.edtDependentes);
        edtDataAdmissão = findViewById(R.id.edtDataAdmissaoFunc);

        edtCargo.setVisibility(View.GONE);
        edtDataAdmissão.setVisibility(View.GONE);
        edtQtDep.setVisibility(View.GONE);
        rd.setVisibility(View.GONE);
        txCargo.setVisibility(View.GONE);
        txDataAdmissão.setVisibility(View.GONE);
        txDep.setVisibility(View.GONE);
        btnFinaliza.setVisibility(View.GONE);
    }
}
