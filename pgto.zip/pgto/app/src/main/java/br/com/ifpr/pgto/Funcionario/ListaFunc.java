package br.com.ifpr.pgto.Funcionario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import br.com.ifpr.pgto.R;

public class ListaFunc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_func);
    }
}
