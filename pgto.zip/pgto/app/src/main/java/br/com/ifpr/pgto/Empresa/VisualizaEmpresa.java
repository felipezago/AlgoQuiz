package br.com.ifpr.pgto.Empresa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import br.com.ifpr.pgto.Firebase.UsuarioFirebase;
import br.com.ifpr.pgto.Util.MaskEditUtil;
import br.com.ifpr.pgto.Model.Empresa;
import br.com.ifpr.pgto.R;

public class VisualizaEmpresa extends AppCompatActivity {

    TextView cnpj, email,  endereco, razao;
    Empresa e = UsuarioFirebase.getDadosEmpresaLogada();
    FirebaseDatabase firebaseDatabase;
    DatabaseReference ref;
    List<Empresa> lista;
    Button btnVoltar, btnEditar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualiza_empresa);

        cnpj = findViewById(R.id.cnpj);
        email= findViewById(R.id.email);
        endereco = findViewById(R.id.end);
        razao = findViewById(R.id.razao);
        lista= new ArrayList<Empresa>();
        btnVoltar = findViewById(R.id.btnVoltar);

        firebaseDatabase = FirebaseDatabase.getInstance();
        ref = firebaseDatabase.getReference().child("Empresas").child(e.getId());
        ref.keepSynced(true);

        lista.add(e);

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Empresa emp = dataSnapshot.getValue(Empresa.class);
                cnpj.setText(emp.getCnpj());
                email.setText(emp.getEmail());
                endereco.setText(emp.getEndereço());
                razao.setText(emp.getRazaoSocial());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        cnpj.addTextChangedListener(MaskEditUtil.maskText(cnpj, MaskEditUtil.FORMAT_CNPJ));

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(VisualizaEmpresa.this, PrincipalEmpresa.class);
                startActivity(i);
                finish();
            }
        });

    }
}
